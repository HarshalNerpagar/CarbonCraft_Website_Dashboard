<tr>
    <td><div class="skeleton tw-h-4 tw-w-32"></div></td>
    <td><div class="skeleton tw-h-4 tw-w-24"></div></td>
    <td><div class="skeleton tw-h-4 tw-w-20"></div></td>
    <td><div class="skeleton tw-h-6 tw-w-20 tw-rounded-full"></div></td>
    <td><div class="skeleton tw-h-4 tw-w-24"></div></td>
    <td><div class="skeleton tw-h-4 tw-w-16"></div></td>
    <td>
        <div class="d-flex align-items-center gap-10 justify-content-center">
            <div class="skeleton tw-size-8 tw-rounded-circle"></div>
            <div class="skeleton tw-size-8 tw-rounded-circle"></div>
            <div class="skeleton tw-size-8 tw-rounded-circle"></div>
        </div>
    </td>
</tr>
