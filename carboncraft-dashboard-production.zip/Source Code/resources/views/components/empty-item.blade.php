<div>
   <div class="tw-min-h-[20rem] tw-w-full tw-flex tw-items-center tw-justify-center tw-flex-col">
        <div class="text-lg">
            No records found.
        </div>
        <div class="text-neutral-400">Add new data to show them here.</div>
   </div>
</div>